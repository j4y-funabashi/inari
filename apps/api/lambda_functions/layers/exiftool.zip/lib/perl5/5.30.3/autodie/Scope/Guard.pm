package autodie::Scope::Guard;

use strict;
use warnings;

# ABSTRACT: Wrapper class for calling subs at end of scope
our $VERSION = '2.29'; # VERSION

# This code schedules the cleanup of subroutines at the end of
# scope.  It's directly inspired by chocolateboy's excellent
# Scope::Guard module.

sub new {
    my ($class, $handler) = @_;
    return bless($handler, $class);
}

sub DESTROY {
    my ($self) = @_;

    $self->();
}

1;

__END__

