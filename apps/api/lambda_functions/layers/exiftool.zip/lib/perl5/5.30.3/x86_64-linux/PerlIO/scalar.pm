package PerlIO::scalar;
our $VERSION = '0.30';
require XSLoader;
XSLoader::load();
1;
__END__

