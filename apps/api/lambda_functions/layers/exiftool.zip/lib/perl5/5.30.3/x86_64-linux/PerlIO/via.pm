package PerlIO::via;
our $VERSION = '0.17';
require XSLoader;
XSLoader::load();
1;
__END__

