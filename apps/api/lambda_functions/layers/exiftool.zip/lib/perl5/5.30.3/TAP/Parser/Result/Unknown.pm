package TAP::Parser::Result::Unknown;

use strict;
use warnings;

use base 'TAP::Parser::Result';


our $VERSION = '3.42';


1;
