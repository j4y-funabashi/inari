package Test2::EventFacet::Info::Table;
use strict;
use warnings;

use Carp qw/confess/;

use Test2::Util::HashBase qw{-header -rows -collapse -no_collapse -as_string};

sub init {
    my $self = shift;

    confess "Table may not be empty" unless ref($self->{+ROWS}) eq 'ARRAY' && @{$self->{+ROWS}};

    $self->{+AS_STRING} ||= '<TABLE NOT DISPLAYED>';
}

sub as_hash { my $out = +{%{$_[0]}}; delete $out->{as_string}; $out }

sub info_args {
    my $self = shift;

    my $hash = $self->as_hash;
    my $desc = $self->as_string;

    return (table => $hash, details => $desc);
}

1;

__END__

