# Call.pm
#
# Copyright (c) 1995-2011 Paul Marquess. All rights reserved.
# Copyright (c) 2011-2014 Reini Urban. All rights reserved.
# Copyright (c) 2014-2017 cPanel Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
 
package Filter::Util::Call ;

require 5.006 ; # our
require Exporter;

use XSLoader ();
use strict;
use warnings;

our @ISA = qw(Exporter);
our @EXPORT = qw( filter_add filter_del filter_read filter_read_exact) ;
our $VERSION = "1.59" ;
our $XS_VERSION = $VERSION;
$VERSION = eval $VERSION;

sub filter_read_exact($)
{
    my ($size)   = @_ ;
    my ($left)   = $size ;
    my ($status) ;

    unless ( $size > 0 ) {
        require Carp;
        Carp::croak("filter_read_exact: size parameter must be > 0");
    }

    # try to read a block which is exactly $size bytes long
    while ($left and ($status = filter_read($left)) > 0) {
        $left = $size - length $_ ;
    }

    # EOF with pending data is a special case
    return 1 if $status == 0 and length $_ ;

    return $status ;
}

sub filter_add($)
{
    my($obj) = @_ ;

    # Did we get a code reference?
    my $coderef = (ref $obj eq 'CODE');

    # If the parameter isn't already a reference, make it one.
    if (!$coderef and (!ref($obj) or ref($obj) =~ /^ARRAY|HASH$/)) {
      $obj = bless (\$obj, (caller)[0]);
    }

    # finish off the installation of the filter in C.
    Filter::Util::Call::real_import($obj, (caller)[0], $coderef) ;
}

XSLoader::load('Filter::Util::Call');

1;
__END__


