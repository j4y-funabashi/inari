package autodie::skip;
use strict;
use warnings;

our $VERSION = '2.29'; # VERSION

# This package exists purely so people can inherit from it,
# which isn't at all how roles are supposed to work, but it's
# how people will use them anyway.

if ($] < 5.010) {
    # Older Perls don't have a native ->DOES.  Let's provide a cheap
    # imitation here.

    *DOES = sub { return shift->isa(@_); };
}

1;

__END__

