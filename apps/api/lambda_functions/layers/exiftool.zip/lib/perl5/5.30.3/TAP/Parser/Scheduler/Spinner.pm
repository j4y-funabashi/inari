package TAP::Parser::Scheduler::Spinner;

use strict;
use warnings;
use Carp;


our $VERSION = '3.42';


sub new { bless {}, shift }


sub is_spinner {1}


1;
