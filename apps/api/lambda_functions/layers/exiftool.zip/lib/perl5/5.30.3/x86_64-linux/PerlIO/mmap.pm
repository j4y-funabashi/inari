package PerlIO::mmap;
use strict;
use warnings;
our $VERSION = '0.016';

use XSLoader;
XSLoader::load(__PACKAGE__, __PACKAGE__->VERSION);

1;

__END__


