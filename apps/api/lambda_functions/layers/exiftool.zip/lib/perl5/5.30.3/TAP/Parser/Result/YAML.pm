package TAP::Parser::Result::YAML;

use strict;
use warnings;

use base 'TAP::Parser::Result';


our $VERSION = '3.42';


##############################################################################


sub data { shift->{data} }

1;
