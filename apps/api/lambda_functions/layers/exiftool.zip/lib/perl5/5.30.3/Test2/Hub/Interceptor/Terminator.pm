package Test2::Hub::Interceptor::Terminator;
use strict;
use warnings;

our $VERSION = '1.302162';


1;

__END__

