package Test2::Util::Trace;
require Test2::EventFacet::Trace;
@ISA = ('Test2::EventFacet::Trace');

our $VERSION = '1.302162';

1;

__END__

