package sort;

our $VERSION = '2.04';

# The hints for pp_sort are now stored in $^H{sort}; older versions
# of perl used the global variable $sort::hints. -- rjh 2005-12-19

$sort::stable_bit      = 0x00000100;
$sort::unstable_bit    = 0x00000200;

use strict;

sub import {
    shift;
    if (@_ == 0) {
	require Carp;
	Carp::croak("sort pragma requires arguments");
    }
    local $_;
    $^H{sort} //= 0;
    while ($_ = shift(@_)) {
	if ($_ eq 'stable') {
	    $^H{sort} |=  $sort::stable_bit;
	    $^H{sort} &= ~$sort::unstable_bit;
	} elsif ($_ eq 'defaults') {
	    $^H{sort} =   0;
	} else {
	    require Carp;
	    Carp::croak("sort: unknown subpragma '$_'");
	}
    }
}

sub unimport {
    shift;
    if (@_ == 0) {
	require Carp;
	Carp::croak("sort pragma requires arguments");
    }
    local $_;
    no warnings 'uninitialized';	# bitops would warn
    while ($_ = shift(@_)) {
	if ($_ eq 'stable') {
	    $^H{sort} &= ~$sort::stable_bit;
	    $^H{sort} |=  $sort::unstable_bit;
	} else {
	    require Carp;
	    Carp::croak("sort: unknown subpragma '$_'");
	}
    }
}

sub current {
    my @sort;
    if ($^H{sort}) {
	push @sort, 'stable'    if $^H{sort} & $sort::stable_bit;
    }
    join(' ', @sort);
}

1;
__END__


