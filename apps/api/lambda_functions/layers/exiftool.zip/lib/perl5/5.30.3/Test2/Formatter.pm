package Test2::Formatter;
use strict;
use warnings;

our $VERSION = '1.302162';


my %ADDED;
sub import {
    my $class = shift;
    return if $class eq __PACKAGE__;
    return if $ADDED{$class}++;
    require Test2::API;
    Test2::API::test2_formatter_add($class);
}

sub new_root {
    my $class = shift;
    return $class->new(@_);
}

sub supports_tables { 0 }

sub hide_buffered { 1 }

sub terminate { }

sub finalize { }

1;

__END__

